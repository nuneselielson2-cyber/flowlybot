export default function Dashboard() {
  return (
    <div className="min-h-screen p-8 bg-gray-50">
      <h1 className="text-3xl font-bold mb-6">Dashboard Flowly</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-4 bg-white rounded shadow">Vendas: R$0,00</div>
        <div className="p-4 bg-white rounded shadow">Pedidos: 0</div>
        <div className="p-4 bg-white rounded shadow">Usuários: 0</div>
      </div>
    </div>
  );
}