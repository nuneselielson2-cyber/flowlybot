import { useState } from "react";
import { useRouter } from "next/router";

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();
    if (email === "elielsonnunes54@gmail.com" && senha === "elielsonsabrina#06") {
      router.push("/dashboard");
    } else {
      alert("Email ou senha incorretos!");
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100">
      <h1 className="text-3xl font-bold mb-6">Painel Flowly</h1>
      <form onSubmit={handleLogin} className="flex flex-col gap-4 bg-white p-8 rounded shadow-md">
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="border p-2 rounded"
          required
        />
        <input
          type="password"
          placeholder="Senha"
          value={senha}
          onChange={(e) => setSenha(e.target.value)}
          className="border p-2 rounded"
          required
        />
        <button type="submit" className="bg-purple-600 text-white p-2 rounded font-bold hover:bg-purple-700 transition">
          Entrar
        </button>
      </form>
    </div>
  );
}